Infinite Runner Ultimate 
                      - Presented by BornFree labs ( www.bornfreelabs.com )
                     
########################################################################### THANKS FOR PURCHASING ############################################################################                     


Thanks for purchasing Infinite Runner Ultimate plugin from Unity Asset Store. Lots of new features have been added in v3. 
The Documentation is no more included as a PDF File but is available online.                


Setting up the project-
   Replace the TagManager.asset with the TagManager.asset of your current project. If that does'nt work Go to Edit - Project Settings - Tags and Layers
   and add the following Layers :-
    1. GroundLayer is Layer 11
    2. EnemyAndWallLayer is Layer 9



* Please read the online documentation before starting.
* Two demo scenes "Desert Ruins", "Basic Scene" have been included.
* This product is licensed under Asset Store License. Please read the Asset Store license carefully.
* Free for commercial use. Credits would be appreciated.
* Use arrow keys to control in demo scenes.
* For other support mail to bornfree@bornfreelabs.com or subhojeetpramanik@gmail.com
* Share with us the amazing games you create with the toolkit. We will be happy to list it on the Showcase page of our website.